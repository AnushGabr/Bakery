const API_URL = 'http://localhost:3000/products'

export {API_URL}